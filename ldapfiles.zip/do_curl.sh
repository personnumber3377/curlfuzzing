curl -v --limit-rate 16384 --location --proxy socks5h://127.0.0.1:8080 http://www.wikipedia.org

