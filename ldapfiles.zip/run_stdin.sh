#!/bin/sh

LD_LIBRARY_PATH=/home/oof/curlsocksfuzzer/ LD_PRELOAD=libdesock.so ./sample_code

